import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";
import Navigation from "@/components/navigation";
import Footer from "@/components/footer";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "Smart Minds Academy - Real-Time Training Institute",
  description: "Transform your career with elite quality training in Life Sciences and Technical courses. Get your dream career on your first attempt with Smart Minds Academy.",
  keywords: ["Smart Minds Academy", "Medical Coding", "Clinical Research", "Python", "Java", "Training Institute", "Placement Support"],
  authors: [{ name: "Smart Minds Academy" }],
  openGraph: {
    title: "Smart Minds Academy of Real-Time Training",
    description: "Elite quality training in Life Sciences and Technical courses with placement support",
    url: "https://smartmindsacademy.com",
    siteName: "Smart Minds Academy",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "Smart Minds Academy",
    description: "Elite quality training in Life Sciences and Technical courses",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        <Navigation />
        <main className="min-h-screen">
          {children}
        </main>
        <Footer />
        <Toaster />
      </body>
    </html>
  );
}
