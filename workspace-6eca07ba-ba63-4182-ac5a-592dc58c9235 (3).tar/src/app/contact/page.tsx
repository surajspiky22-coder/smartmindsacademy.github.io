'use client'

import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import { 
  Phone, 
  Mail, 
  MapPin, 
  Clock, 
  MessageCircle,
  Send,
  CheckCircle,
  Users,
  Award,
  TrendingUp
} from 'lucide-react'

export default function ContactPage() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    course: '',
    message: ''
  })
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isSubmitted, setIsSubmitted] = useState(false)

  const contactInfo = [
    {
      icon: Phone,
      title: "Phone",
      value: "+91 9030070602 - SURAJ SIR",
      description: "Monday to Saturday, 9AM to 6PM"
    },
    {
      icon: Mail,
      title: "Email",
      value: "smartmindsins@gmail.com",
      description: "We'll respond within 24 hours"
    },
    {
      icon: MapPin,
      title: "Hyderabad Address",
      value: "A.S.Rao Nagar, Kapra, Hyderabad, Telangana - 500062",
      description: "Visit us for a campus tour"
    },
    {
      icon: Clock,
      title: "Working Hours",
      value: "Mon - Sat: 9AM - 6PM",
      description: "Sunday: Closed"
    }
  ]

  const courses = [
    "Advanced Medical Coding",
    "CPC Medical Coding",
    "Clinical Research",
    "Pharmacovigilance",
    "Python Programming",
    "Java Programming",
    "Other"
  ]

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target
    setFormData(prev => ({
      ...prev,
      [name]: value
    }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)
    
    try {
      // Create email content
      const emailSubject = `New Contact Form Submission from ${formData.name}`
      const emailBody = `
Name: ${formData.name}
Email: ${formData.email}
Phone: ${formData.phone}
Course Interest: ${formData.course}
Message: ${formData.message}

Submitted on: ${new Date().toLocaleString()}
      `.trim()

      // Open email client with pre-filled content
      const emailUrl = `mailto:smartmindsins@gmail.com?subject=${encodeURIComponent(emailSubject)}&body=${encodeURIComponent(emailBody)}`
      
      // Open WhatsApp with pre-filled message
      const whatsappMessage = `New Contact Form Submission:%0A%0AName: ${formData.name}%0AEmail: ${formData.email}%0APhone: ${formData.phone}%0ACourse: ${formData.course}%0AMessage: ${formData.message}%0A%0ASubmitted on: ${new Date().toLocaleString()}`
      const whatsappUrl = `https://wa.me/919030070602?text=${whatsappMessage}`

      // Open both email and WhatsApp in new tabs
      window.open(emailUrl, '_blank')
      window.open(whatsappUrl, '_blank')
      
      // Simulate processing time
      await new Promise(resolve => setTimeout(resolve, 1000))
      
      setIsSubmitting(false)
      setIsSubmitted(true)
      
      // Reset form after 3 seconds
      setTimeout(() => {
        setIsSubmitted(false)
        setFormData({
          name: '',
          email: '',
          phone: '',
          course: '',
          message: ''
        })
      }, 3000)
    } catch (error) {
      setIsSubmitting(false)
      console.error('Error submitting form:', error)
    }
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-gradient-to-r from-maroon-600 to-maroon-800 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <div className="text-center">
            <h1 className="text-4xl font-bold mb-4">Contact Us</h1>
            <p className="text-xl opacity-90 max-w-3xl mx-auto">
              Have questions about our courses or need guidance? Get in touch with our expert team. 
              We're here to help you take the first step towards your dream career.
            </p>
          </div>
        </div>
      </div>

      {/* Contact Information */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {contactInfo.map((info, index) => (
              <Card key={index} className="text-center">
                <CardHeader>
                  <info.icon className="h-12 w-12 text-maroon-600 mx-auto mb-4" />
                  <CardTitle className="text-xl">{info.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="font-semibold text-gray-900 mb-2">{info.value}</p>
                  <p className="text-sm text-gray-600">{info.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
          
          {/* Additional Contact Info */}
          <div className="mt-12 grid md:grid-cols-2 gap-8">
            <Card>
              <CardHeader>
                <CardTitle className="text-xl flex items-center gap-2">
                  <Phone className="h-5 w-5 text-maroon-600" />
                  Additional Contact Numbers
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <p className="text-gray-700">+91 99297623402 - SATYA MA'AM</p>
                <p className="text-gray-700">+91 7780508023 - SHABNA MA'AM</p>
                <p className="text-gray-700">+91 7799447861 - MASTANI MA'AM</p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle className="text-xl flex items-center gap-2">
                  <MapPin className="h-5 w-5 text-maroon-600" />
                  Andhra Pradesh Address
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-700">
                  Station Thota near Sai Baba Temple Beside Nagendra Swamy Temple, Nuzvid, Andhra Pradesh - 521201
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Contact Form and Map */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12">
            {/* Contact Form */}
            <div>
              <Card>
                <CardHeader>
                  <CardTitle className="text-2xl flex items-center gap-2">
                    <MessageCircle className="h-6 w-6 text-maroon-600" />
                    Get in Touch
                  </CardTitle>
                  <CardDescription className="text-lg">
                    Fill out the form below and we'll get back to you soon
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {isSubmitted ? (
                    <div className="text-center py-8">
                      <CheckCircle className="h-16 w-16 text-green-500 mx-auto mb-4" />
                      <h3 className="text-xl font-semibold text-gray-900 mb-2">
                        Thank You!
                      </h3>
                      <p className="text-gray-600 mb-4">
                        Your message has been sent successfully!
                      </p>
                      <div className="space-y-2 text-sm text-gray-500">
                        <p>📧 Email sent to: smartmindsins@gmail.com</p>
                        <p>📱 WhatsApp message sent to: +91 9030070602</p>
                        <p className="font-medium text-maroon-600">We'll get back to you soon!</p>
                      </div>
                    </div>
                  ) : (
                    <form onSubmit={handleSubmit} className="space-y-6">
                      <div className="grid md:grid-cols-2 gap-4">
                        <div>
                          <Label htmlFor="name">Full Name *</Label>
                          <Input
                            id="name"
                            name="name"
                            type="text"
                            required
                            value={formData.name}
                            onChange={handleInputChange}
                            placeholder="Enter your full name"
                          />
                        </div>
                        <div>
                          <Label htmlFor="email">Email Address *</Label>
                          <Input
                            id="email"
                            name="email"
                            type="email"
                            required
                            value={formData.email}
                            onChange={handleInputChange}
                            placeholder="Enter your email"
                          />
                        </div>
                      </div>

                      <div className="grid md:grid-cols-2 gap-4">
                        <div>
                          <Label htmlFor="phone">Phone Number</Label>
                          <Input
                            id="phone"
                            name="phone"
                            type="tel"
                            value={formData.phone}
                            onChange={handleInputChange}
                            placeholder="Enter your phone number"
                          />
                        </div>
                        <div>
                          <Label htmlFor="course">Course Interest</Label>
                          <select
                            id="course"
                            name="course"
                            value={formData.course}
                            onChange={handleInputChange}
                            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-maroon-500"
                          >
                            <option value="">Select a course</option>
                            {courses.map((course) => (
                              <option key={course} value={course}>
                                {course}
                              </option>
                            ))}
                          </select>
                        </div>
                      </div>

                      <div>
                        <Label htmlFor="message">Message *</Label>
                        <Textarea
                          id="message"
                          name="message"
                          required
                          rows={5}
                          value={formData.message}
                          onChange={handleInputChange}
                          placeholder="Tell us about your interests, goals, or any questions you have..."
                        />
                      </div>

                      <Button 
                        type="submit" 
                        className="w-full bg-maroon-600 hover:bg-maroon-700" 
                        size="lg"
                        disabled={isSubmitting}
                      >
                        {isSubmitting ? (
                          <>
                            <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                            Submitting...
                          </>
                        ) : (
                          <>
                            <Send className="h-4 w-4 mr-2" />
                            Submit Student Data
                          </>
                        )}
                      </Button>
                    </form>
                  )}
                </CardContent>
              </Card>
            </div>

            {/* Quick Info and Map */}
            <div className="space-y-8">
              {/* Quick Response Card */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-xl">Quick Response</CardTitle>
                  <CardDescription>
                    We typically respond to inquiries within 24 hours
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center gap-3">
                    <Badge variant="secondary">📧 Email</Badge>
                    <span className="text-sm">Response within 24 hours</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <Badge variant="secondary">📞 Phone</Badge>
                    <span className="text-sm">Immediate assistance</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <Badge variant="secondary">🏢 Visit</Badge>
                    <span className="text-sm">Campus tour available</span>
                  </div>
                </CardContent>
              </Card>

              {/* Office Hours */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-xl">Office Hours</CardTitle>
                  <CardDescription>
                    Best times to reach us
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex justify-between">
                    <span className="font-medium">Monday - Friday</span>
                    <span className="text-maroon-600">9:00 AM - 6:00 PM</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="font-medium">Saturday</span>
                    <span className="text-maroon-600">9:00 AM - 2:00 PM</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="font-medium">Sunday</span>
                    <span className="text-gray-500">Closed</span>
                  </div>
                </CardContent>
              </Card>

              {/* Emergency Contact */}
              <Card className="border-maroon-200">
                <CardHeader>
                  <CardTitle className="text-xl text-maroon-600">Urgent Inquiries</CardTitle>
                  <CardDescription>
                    For immediate assistance with course enrollment
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <p className="font-semibold">📞 +91 9030070602</p>
                    <p className="text-sm text-gray-600">
                      Available for urgent course-related queries only
                    </p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Our Team Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Our Team</h2>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              At Smart Minds Academy, our team is made up of expert instructors and strong leadership. We focus on improving education at every step.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <Card className="text-center">
              <CardHeader>
                <div className="w-20 h-20 bg-maroon-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Users className="h-10 w-10 text-maroon-600" />
                </div>
                <CardTitle>Expert Instructors</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">
                  Our dedicated teachers motivate and guide each student to reach their goals, making sure the learning experience is ongoing and rewarding.
                </p>
              </CardContent>
            </Card>

            <Card className="text-center">
              <CardHeader>
                <div className="w-20 h-20 bg-maroon-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Award className="h-10 w-10 text-maroon-600" />
                </div>
                <CardTitle>Strong Leadership</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">
                  Our leadership team provides strategic direction and ensures the highest quality standards in education and training.
                </p>
              </CardContent>
            </Card>

            <Card className="text-center">
              <CardHeader>
                <div className="w-20 h-20 bg-maroon-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <TrendingUp className="h-10 w-10 text-maroon-600" />
                </div>
                <CardTitle>Continuous Improvement</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">
                  We focus on improving education at every step, constantly updating our curriculum and teaching methods.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-16 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Frequently Asked Questions</h2>
            <p className="text-lg text-gray-600">
              Quick answers to common questions
            </p>
          </div>

          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">What courses do you offer?</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">
                  We offer Life Science courses (Medical Coding, Clinical Research, Pharmacovigilance) 
                  and Technical courses (Python, Java, Prompt Engineering, Tally with GST, C++).
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-lg">What is the fee structure?</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">
                  We offer the most affordable fees with elite quality training. Course fees range depends on the course duration and content. kindly contact us without any hesitation and feel free to contact us
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Do you provide placement assistance?</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">
                  Yes, we provide comprehensive placement support including resume building, mock interviews, 
                  and direct placement drives with our 10+ partner companies.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Are study materials included?</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">
                  Yes, we provide free comprehensive study materials, interview questions, 
                  and access to mock tests and assessments.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-lg">When we can get place in the companies? or when can we get placements?</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">
                  Every student of our institute got placed within their first attempt itself, but needs to maintain regular attendance and should revise the topics discussed by trainer and should follow the subject instructions said by trainer
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-maroon-600 text-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold mb-4">Ready to Start Your Journey?</h2>
          <p className="text-xl mb-8 opacity-90">
            Take the first step towards your dream career today
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button 
              size="lg" 
              variant="secondary" 
              className="text-lg px-8 py-4 bg-white text-maroon-600 hover:bg-gray-100"
              onClick={() => window.open('https://wa.me/919030070602', '_blank')}
            >
              Enroll Now
            </Button>
            <Button asChild size="lg" variant="outline" className="text-lg px-8 py-4 border-white text-white hover:bg-white hover:text-maroon-600">
              <a href="/courses">View Courses</a>
            </Button>
          </div>
        </div>
      </section>
    </div>
  )
}