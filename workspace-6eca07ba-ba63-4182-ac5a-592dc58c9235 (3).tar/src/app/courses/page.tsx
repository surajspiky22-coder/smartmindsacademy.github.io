'use client'

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { 
  GraduationCap, 
  Award, 
  Clock, 
  Users, 
  Star, 
  BookOpen,
  CheckCircle,
  TrendingUp
} from 'lucide-react'

export default function CoursesPage() {
  const lifeScienceCourses = [
    {
      title: "Medical Coding Certification Course",
      description: "Comprehensive medical coding training with certification preparation",
      duration: "30 days",
      students: "300+",
      rating: 4.7,
      features: [
        "Medical Terminology",
        "ICD-10 Coding Basics",
        "CPT Coding Fundamentals",
        "HCPCS Level II",
        "Certification Preparation",
        "Real-world Case Studies"
      ]
    },
    {
      title: "Advanced Medical Coding Training (AMCT)",
      description: "Advanced training in medical coding with real-world case studies",
      duration: "2.5 months",
      students: "500+",
      rating: 4.8,
      features: [
        "ICD-10, CPT, HCPCS Coding",
        "Advanced Medical Terminology",
        "Anatomy & Physiology",
        "Real-time Projects",
        "Compliance Training",
        "Certification Support"
      ]
    },
    {
      title: "CPC Certification Training (Certified Professional Coder)",
      description: "Specialized training for Certified Professional Coder (CPC) certification",
      duration: "3 months",
      students: "750+",
      rating: 4.9,
      features: [
        "CPC Exam Preparation",
        "Medical Guidelines & Regulations",
        "Compliance Training",
        "Mock Exams",
        "Job Placement Assistance",
        "Industry Best Practices"
      ]
    },
    {
      title: "CRC Certification Training (Certified Risk Adjustment Coder)",
      description: "Certified Risk Adjustment Coder training with practical applications",
      duration: "3 months",
      students: "300+",
      rating: 4.7,
      features: [
        "Risk Adjustment Models",
        "HCC Coding",
        "Documentation Review",
        "Quality Measures",
        "Compliance Training",
        "Industry Best Practices"
      ]
    },
    {
      title: "CCS Medical Coding Training",
      description: "Certified Coding Specialist training for hospital coding",
      duration: "3 months",
      students: "400+",
      rating: 4.8,
      features: [
        "Inpatient Coding",
        "Outpatient Coding",
        "DRG Assignment",
        "Hospital Billing",
        "CCS Certification Prep",
        "Real-time Projects"
      ]
    },
    {
      title: "Advanced Medical Billing Training (AMBT)",
      description: "Comprehensive medical billing with latest industry practices",
      duration: "2.5 months",
      students: "350+",
      rating: 4.6,
      features: [
        "Billing Software",
        "Insurance Claims",
        "Revenue Cycle",
        "Denial Management",
        "Compliance Training",
        "Accounts Receivable"
      ]
    },
    {
      title: "Pharmacovigilance and Materiovigilance",
      description: "Drug safety monitoring and medical device surveillance training",
      duration: "2 months",
      students: "150+",
      rating: 4.9,
      features: [
        "Adverse Event Reporting",
        "Signal Detection",
        "Risk Management",
        "Regulatory Affairs",
        "Case Processing",
        "Industry Standards"
      ]
    },
    {
      title: "Clinical Data Management",
      description: "Complete clinical data management with industry-standard tools",
      duration: "2 months",
      students: "150+ students placed",
      rating: 4.8,
      features: [
        "CDISC Standards",
        "Database Design",
        "Data Validation",
        "SAS Programming",
        "FDA Guidelines",
        "Clinical Trials"
      ]
    },
    {
      title: "Clinical Research",
      description: "Comprehensive clinical research coordinator and monitoring training",
      duration: "2 months",
      students: "300+",
      rating: 4.9,
      features: [
        "Trial Design",
        "GCP Guidelines",
        "Monitoring Visits",
        "Regulatory Submissions",
        "Site Management",
        "Industry Best Practices"
      ]
    }
  ]

  const technicalCourses = [
    {
      title: "Prompt Engineering",
      description: "Master the art of AI prompt engineering and LLM interactions",
      duration: "3 months",
      students: "150+",
      rating: 4.7,
      features: [
        "LLM Fundamentals",
        "Prompt Design",
        "Chain of Thought",
        "Fine-tuning",
        "Real-world Projects",
        "AI Applications"
      ]
    },
    {
      title: "Python Programming",
      description: "Complete Python programming from basics to advanced concepts",
      duration: "2.5 months",
      students: "600+",
      rating: 4.8,
      features: [
        "Python Basics",
        "Data Structures",
        "OOP Concepts",
        "Django/Flask",
        "Project Development",
        "Industry Applications"
      ]
    },
    {
      title: "Java Programming",
      description: "Comprehensive Java development with enterprise applications",
      duration: "2.5 months",
      students: "450+",
      rating: 4.7,
      features: [
        "Core Java",
        "Advanced Java",
        "Spring Framework",
        "Database Integration",
        "Web Development",
        "Enterprise Applications"
      ]
    },
    {
      title: "Tally with GST & C++",
      description: "Complete accounting training with Tally, GST compliance and C++ programming",
      duration: "3 months",
      students: "800+",
      rating: 4.9,
      features: [
        "Tally Fundamentals",
        "GST Compliance",
        "Taxation",
        "Payroll",
        "C++ Programming",
        "Financial Reports"
      ]
    }
  ]

  const CourseCard = ({ course }: { course: any }) => (
    <Card className="h-full hover:shadow-lg transition-shadow duration-300">
      <CardHeader>
        <div className="flex justify-between items-start mb-2">
          <CardTitle className="text-xl leading-tight">{course.title}</CardTitle>
          <Badge variant="secondary" className="ml-2 bg-maroon-100 text-maroon-800">
            Advanced
          </Badge>
        </div>
        <CardDescription className="text-base">
          {course.description}
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {/* Course Stats */}
          <div className="flex items-center justify-between text-sm text-gray-600">
            <div className="flex items-center gap-1">
              <Clock className="h-4 w-4" />
              {course.duration}
            </div>
            <div className="flex items-center gap-1">
              <Users className="h-4 w-4" />
              {course.students}
            </div>
            <div className="flex items-center gap-1">
              <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
              {course.rating}
            </div>
          </div>

          {/* Features */}
          <div className="space-y-2">
            <h4 className="font-semibold text-sm">Course Features:</h4>
            <div className="grid gap-1">
              {course.features.slice(0, 3).map((feature: string, index: number) => (
                <div key={index} className="flex items-center gap-2 text-sm">
                  <CheckCircle className="h-3 w-3 text-green-500 flex-shrink-0" />
                  <span>{feature}</span>
                </div>
              ))}
              {course.features.length > 3 && (
                <div className="text-xs text-gray-500 ml-5">
                  +{course.features.length - 3} more features
                </div>
              )}
            </div>
          </div>

          {/* CTA Button */}
          <Button 
            className="w-full" 
            size="sm"
            onClick={() => window.open('https://wa.me/919030070602', '_blank')}
          >
            Enroll Now
          </Button>
        </div>
      </CardContent>
    </Card>
  )

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="text-center">
            <h1 className="text-4xl font-bold text-gray-900 mb-4">Our Courses</h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto mb-6">
              At SmartMinds Academy, we specialize in providing comprehensive training in Medical Coding and Certification, Medical Billing, CPC Medical Coding Training, and more. As a rapidly evolving and dynamic organization, we offer real-time, job-oriented training programs that are designed to equip students with the skills needed to succeed in their careers.
            </p>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              Our services include certified courses, hands-on training, and expert-led sessions in fields such as Python, Prompt Engineering, Tally with GST, Pharmacovigilance, and Clinical Data Management. With a focus on affordability and practical knowledge, we ensure that students are fully prepared to excel in job interviews and thrive in their professional journeys.
            </p>
          </div>
        </div>
      </div>

      {/* Course Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <Tabs defaultValue="life-science" className="w-full">
          <TabsList className="grid w-full grid-cols-2 mb-8">
            <TabsTrigger value="life-science" className="text-lg py-3">
              <GraduationCap className="h-5 w-5 mr-2" />
              Life Science Courses
            </TabsTrigger>
            <TabsTrigger value="technical" className="text-lg py-3">
              <Award className="h-5 w-5 mr-2" />
              Technical Courses
            </TabsTrigger>
          </TabsList>

          <TabsContent value="life-science" className="space-y-6">
            <div className="text-center mb-8">
              <h2 className="text-3xl font-bold text-gray-900 mb-2">Life Science Courses</h2>
              <p className="text-lg text-gray-600">
                Industry-leading programs in healthcare, medical coding, and clinical research
              </p>
            </div>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {lifeScienceCourses.map((course, index) => (
                <CourseCard key={index} course={course} />
              ))}
            </div>
          </TabsContent>

          <TabsContent value="technical" className="space-y-6">
            <div className="text-center mb-8">
              <h2 className="text-3xl font-bold text-gray-900 mb-2">Technical Courses</h2>
              <p className="text-lg text-gray-600">
                Cutting-edge technology and programming courses for the digital age
              </p>
            </div>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {technicalCourses.map((course, index) => (
                <CourseCard key={index} course={course} />
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </div>

      {/* Benefits Section */}
      <section className="bg-maroon-600 text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">What You Get With Every Course</h2>
            <p className="text-xl opacity-90">Comprehensive support for your learning journey</p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="text-center">
              <BookOpen className="h-12 w-12 mx-auto mb-4" />
              <h3 className="text-xl font-semibold mb-2">Free Materials</h3>
              <p className="opacity-90">Comprehensive study materials and resources</p>
            </div>
            <div className="text-center">
              <TrendingUp className="h-12 w-12 mx-auto mb-4" />
              <h3 className="text-xl font-semibold mb-2">Mock Tests</h3>
              <p className="opacity-90">Regular assessments and mock interviews</p>
            </div>
            <div className="text-center">
              <Users className="h-12 w-12 mx-auto mb-4" />
              <h3 className="text-xl font-semibold mb-2">Expert Faculty</h3>
              <p className="opacity-90">Industry experts with real-world experience</p>
            </div>
            <div className="text-center">
              <CheckCircle className="h-12 w-12 mx-auto mb-4" />
              <h3 className="text-xl font-semibold mb-2">Placement Support</h3>
              <p className="opacity-90">Resume building and job placement assistance</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}