'use client'

import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { 
  GraduationCap, 
  BookOpen, 
  Users, 
  Award, 
  CheckCircle, 
  TrendingUp,
  Clock,
  FileText,
  MessageSquare,
  Briefcase,
  ArrowRight
} from 'lucide-react'

export default function Home() {
  const lifeScienceCourses = [
    "Advanced Medical Coding Training",
    "CPC Medical Coding Training",
    "CRC Medical Coding Training",
    "CCS Medical Coding Training",
    "Advanced Medical Billing Training",
    "Pharmacovigilance and Materiovigilance",
    "Clinical Data Management",
    "Clinical Research"
  ]

  const technicalCourses = [
    "Prompt Engineering",
    "Python Coding",
    "Java",
    "Tally with GST",
    "C++ Courses"
  ]

  const features = [
    {
      icon: BookOpen,
      title: "Free Materials",
      description: "Comprehensive study materials and resources provided at no extra cost"
    },
    {
      icon: FileText,
      title: "Topic Wise Interview Questions",
      description: "Curated interview questions for each topic to boost your preparation"
    },
    {
      icon: Clock,
      title: "Assessments & Mock Tests",
      description: "Regular topic-wise assessments and mock tests to track your progress"
    },
    {
      icon: MessageSquare,
      title: "Mock Interviews",
      description: "Practice interviews with industry experts to build confidence"
    },
    {
      icon: Briefcase,
      title: "Resume Building",
      description: "Professional resume building assistance to showcase your skills"
    },
    {
      icon: Users,
      title: "Soft Skills Training",
      description: "Interview soft skills and personality development training"
    }
  ]

  return (
    <div className="flex flex-col">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-maroon-50 to-maroon-100 py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-5xl md:text-7xl font-bold text-gray-900 mb-4">
              SMART MINDS
            </h1>
            <p className="text-xl md:text-2xl text-gray-600 mb-8">
              ACADEMY OF REAL-TIME TRAINING
            </p>
            <div className="text-3xl md:text-4xl font-bold text-maroon-600 mb-6">
              TRAIN - TRANSFORM - TRIUMPH
            </div>
            <div className="text-2xl md:text-3xl font-bold text-yellow-600 mb-8 bg-yellow-50 inline-block px-6 py-3 rounded-lg border-2 border-yellow-300">
              ACHIEVE YOUR DREAM CAREER ON YOUR VERY FIRST ATTEMPT
            </div>
            <p className="text-xl text-gray-700 mb-12 max-w-3xl mx-auto">
              Smart Minds Academy is a premier training institute offering high-quality courses. We provide affordable prices every student can take our courses, yet effective, ensuring every student learns in a simple and effective manner, enabling them to ace job interviews on their first attempt. Led by highly qualified and experienced trainers, our focus is on making learning easy through real-life examples from nature.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
              <Button 
                size="lg" 
                className="text-lg px-8 py-4 bg-maroon-600 hover:bg-maroon-700"
                onClick={() => window.open('https://wa.me/919030070602', '_blank')}
              >
                Enroll Now
              </Button>
              <Button asChild variant="outline" size="lg" className="text-lg px-8 py-4 border-maroon-600 text-maroon-600 hover:bg-maroon-600 hover:text-white flex items-center gap-2">
                <Link href="/courses" className="flex items-center gap-2">
                  <BookOpen className="h-5 w-5" />
                  Explore Courses
                  <ArrowRight className="h-4 w-4" />
                </Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Courses Overview */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Our Courses</h2>
            <p className="text-xl text-gray-600">Comprehensive training programs designed for your success</p>
          </div>

          <div className="grid md:grid-cols-2 gap-12">
            {/* Life Science Courses */}
            <Card className="h-full">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-2xl">
                  <GraduationCap className="h-8 w-8 text-maroon-600" />
                  Life Science Courses
                </CardTitle>
                <CardDescription className="text-lg">
                  Industry-leading programs in healthcare and life sciences
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid gap-3">
                  {lifeScienceCourses.map((course, index) => (
                    <div key={index} className="flex items-center gap-2">
                      <CheckCircle className="h-4 w-4 text-green-500 flex-shrink-0" />
                      <span className="text-gray-700">{course}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Technical Courses */}
            <Card className="h-full">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-2xl">
                  <Award className="h-8 w-8 text-maroon-600" />
                  Technical Courses
                </CardTitle>
                <CardDescription className="text-lg">
                  Cutting-edge technology and programming courses
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid gap-3">
                  {technicalCourses.map((course, index) => (
                    <div key={index} className="flex items-center gap-2">
                      <CheckCircle className="h-4 w-4 text-green-500 flex-shrink-0" />
                      <span className="text-gray-700">{course}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Why Choose Smart Minds?</h2>
            <p className="text-xl text-gray-600">Comprehensive support for your career journey</p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <Card key={index} className="text-center h-full">
                <CardHeader>
                  <feature.icon className="h-12 w-12 text-maroon-600 mx-auto mb-4" />
                  <CardTitle className="text-xl">{feature.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-base">
                    {feature.description}
                  </CardDescription>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Philosophy Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Our Philosophy</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Everyone should dream, everyone should achieve their dreams, and we make sure those dreams turn into successful careers.
            </p>
          </div>
        </div>
      </section>

      {/* Mission Section */}
      <section className="py-20 bg-maroon-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-4xl font-bold text-gray-900 mb-6">Our Mission</h2>
              <p className="text-lg text-gray-700 mb-6">
                Our mission is to provide accessible and high-quality training that helps every student realize their dreams and achieve success in their chosen fields. Through expert guidance and innovative teaching methods, we aim to shape the future of our students by making learning an enjoyable and transformative experience.
              </p>
            </div>
            <div className="bg-white p-8 rounded-lg shadow-lg">
              <h3 className="text-2xl font-bold text-gray-900 mb-4">What We Offer</h3>
              <p className="text-gray-700 mb-4">
                At SmartMinds Academy, we specialize in providing comprehensive training in:
              </p>
              <ul className="space-y-2 text-gray-700">
                <li className="flex items-center space-x-2">
                  <CheckCircle className="h-4 w-4 text-green-500" />
                  <span>Medical Coding and Certification</span>
                </li>
                <li className="flex items-center space-x-2">
                  <CheckCircle className="h-4 w-4 text-green-500" />
                  <span>Medical Billing</span>
                </li>
                <li className="flex items-center space-x-2">
                  <CheckCircle className="h-4 w-4 text-green-500" />
                  <span>CPC Medical Coding Training</span>
                </li>
                <li className="flex items-center space-x-2">
                  <CheckCircle className="h-4 w-4 text-green-500" />
                  <span>Python Programming</span>
                </li>
                <li className="flex items-center space-x-2">
                  <CheckCircle className="h-4 w-4 text-green-500" />
                  <span>Prompt Engineering</span>
                </li>
                <li className="flex items-center space-x-2">
                  <CheckCircle className="h-4 w-4 text-green-500" />
                  <span>Tally with GST</span>
                </li>
                <li className="flex items-center space-x-2">
                  <CheckCircle className="h-4 w-4 text-green-500" />
                  <span>Pharmacovigilance</span>
                </li>
                <li className="flex items-center space-x-2">
                  <CheckCircle className="h-4 w-4 text-green-500" />
                  <span>Clinical Data Management</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* How We Achieve This Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">How We Achieve This</h2>
            <p className="text-xl text-gray-600">Our innovative approach to education</p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            <Card className="text-center h-full">
              <CardHeader>
                <div className="w-16 h-16 bg-maroon-600 text-white rounded-full flex items-center justify-center mx-auto mb-4">
                  <BookOpen className="h-8 w-8" />
                </div>
                <CardTitle>Online Learning</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">
                  We use online learning to help students easily move from classroom lessons to practical, real-life experiences.
                </p>
              </CardContent>
            </Card>

            <Card className="text-center h-full">
              <CardHeader>
                <div className="w-16 h-16 bg-maroon-600 text-white rounded-full flex items-center justify-center mx-auto mb-4">
                  <MessageSquare className="h-8 w-8" />
                </div>
                <CardTitle>Communication Skills</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">
                  Our special classes are designed to improve how students communicate and build confidence, helping them thrive in the workplace.
                </p>
              </CardContent>
            </Card>

            <Card className="text-center h-full">
              <CardHeader>
                <div className="w-16 h-16 bg-maroon-600 text-white rounded-full flex items-center justify-center mx-auto mb-4">
                  <Users className="h-8 w-8" />
                </div>
                <CardTitle>Industry Connections</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">
                  We arrange monthly sessions with experts from the industry to share important knowledge. We also provide hands-on training to make sure our students are ready for their careers.
                </p>
              </CardContent>
            </Card>
          </div>

          {/* Vision and Focus Section */}
          <div className="mt-16">
            {/* Vision Section - Centered */}
            <div className="text-center mb-12">
              <div className="w-16 h-16 bg-maroon-600 text-white rounded-full flex items-center justify-center mx-auto mb-6">
                <span className="text-xl font-bold">1</span>
              </div>
              <h3 className="text-3xl font-bold text-gray-900 mb-4">Vision</h3>
              <p className="text-xl text-gray-600 leading-relaxed max-w-4xl mx-auto">
                To be a leading educational platform that empowers individuals with practical, industry-relevant skills, enabling them to achieve their professional goals and lead successful careers.
              </p>
            </div>

            {/* Focus Section */}
            <div className="text-center">
              <div className="w-16 h-16 bg-maroon-600 text-white rounded-full flex items-center justify-center mx-auto mb-6">
                <span className="text-xl font-bold">2</span>
              </div>
              <h3 className="text-3xl font-bold text-gray-900 mb-4">Focus</h3>
              <p className="text-xl text-gray-600 leading-relaxed max-w-4xl mx-auto">
                Making learning easy through real-life examples from nature and practical applications.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Reviews and Ratings Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Student Reviews & Ratings</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Hear from our successful students who have transformed their careers with Smart Minds Academy
            </p>
            <div className="flex items-center justify-center mt-6">
              <div className="flex items-center">
                {[...Array(5)].map((_, i) => (
                  <svg key={i} className="w-8 h-8 text-yellow-400 fill-current" viewBox="0 0 20 20">
                    <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                  </svg>
                ))}
              </div>
              <span className="ml-4 text-3xl font-bold text-gray-900">4.9</span>
              <span className="ml-2 text-lg text-gray-600">out of 5</span>
            </div>
            <p className="text-sm text-gray-500 mt-2">Based on 500+ reviews</p>

          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {/* Review 1 */}
            <Card className="h-full">
              <CardHeader>
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center">
                    <div className="w-12 h-12 bg-maroon-100 rounded-full flex items-center justify-center mr-4">
                      <span className="text-maroon-600 font-bold text-lg">R</span>
                    </div>
                    <div>
                      <h4 className="font-semibold text-gray-900">Ravi Kumar</h4>
                      <p className="text-sm text-gray-600">Medical Coding Student</p>
                    </div>
                  </div>
                  <div className="flex">
                    {[...Array(5)].map((_, i) => (
                      <svg key={i} className="w-4 h-4 text-yellow-400 fill-current" viewBox="0 0 20 20">
                        <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                      </svg>
                    ))}
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-gray-700 italic">
                  "Excellent training institute! Ravan sir's teaching methods are outstanding. The practical examples and real-life scenarios made learning medical coding so easy. Got placed in my first interview itself. Highly recommended!"
                </p>
                <p className="text-sm text-gray-500 mt-4">2 weeks ago</p>
              </CardContent>
            </Card>

            {/* Review 2 */}
            <Card className="h-full">
              <CardHeader>
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center">
                    <div className="w-12 h-12 bg-maroon-100 rounded-full flex items-center justify-center mr-4">
                      <span className="text-maroon-600 font-bold text-lg">P</span>
                    </div>
                    <div>
                      <h4 className="font-semibold text-gray-900">Priya Sharma</h4>
                      <p className="text-sm text-gray-600">Clinical Research Student</p>
                    </div>
                  </div>
                  <div className="flex">
                    {[...Array(5)].map((_, i) => (
                      <svg key={i} className="w-4 h-4 text-yellow-400 fill-current" viewBox="0 0 20 20">
                        <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                      </svg>
                    ))}
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-gray-700 italic">
                  "Best institute for clinical research training! The faculty is very supportive and the course content is comprehensive. They provide excellent placement support. Thank you Smart Minds Academy for helping me achieve my dream career!"
                </p>
                <p className="text-sm text-gray-500 mt-4">1 month ago</p>
              </CardContent>
            </Card>

            {/* Review 3 */}
            <Card className="h-full">
              <CardHeader>
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center">
                    <div className="w-12 h-12 bg-maroon-100 rounded-full flex items-center justify-center mr-4">
                      <span className="text-maroon-600 font-bold text-lg">S</span>
                    </div>
                    <div>
                      <h4 className="font-semibold text-gray-900">Suresh Reddy</h4>
                      <p className="text-sm text-gray-600">Python Programming Student</p>
                    </div>
                  </div>
                  <div className="flex">
                    {[...Array(5)].map((_, i) => (
                      <svg key={i} className="w-4 h-4 text-yellow-400 fill-current" viewBox="0 0 20 20">
                        <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                      </svg>
                    ))}
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-gray-700 italic">
                  "Amazing experience at Smart Minds Academy! The Python course was well-structured and the trainers were very knowledgeable. The practical sessions helped me gain confidence. Got placed in a top MNC with a good package!"
                </p>
                <p className="text-sm text-gray-500 mt-4">3 weeks ago</p>
              </CardContent>
            </Card>

            {/* Review 4 */}
            <Card className="h-full">
              <CardHeader>
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center">
                    <div className="w-12 h-12 bg-maroon-100 rounded-full flex items-center justify-center mr-4">
                      <span className="text-maroon-600 font-bold text-lg">A</span>
                    </div>
                    <div>
                      <h4 className="font-semibold text-gray-900">Anjali Patel</h4>
                      <p className="text-sm text-gray-600">Pharmacovigilance Student</p>
                    </div>
                  </div>
                  <div className="flex">
                    {[...Array(5)].map((_, i) => (
                      <svg key={i} className="w-4 h-4 text-yellow-400 fill-current" viewBox="0 0 20 20">
                        <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                      </svg>
                    ))}
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-gray-700 italic">
                  "Smart Minds Academy is the best place for pharmacovigilance training. The faculty is very experienced and the course material is excellent. They provide great placement assistance. I'm now working in a reputed company thanks to their training!"
                </p>
                <p className="text-sm text-gray-500 mt-4">1 month ago</p>
              </CardContent>
            </Card>

            {/* Review 5 */}
            <Card className="h-full">
              <CardHeader>
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center">
                    <div className="w-12 h-12 bg-maroon-100 rounded-full flex items-center justify-center mr-4">
                      <span className="text-maroon-600 font-bold text-lg">M</span>
                    </div>
                    <div>
                      <h4 className="font-semibold text-gray-900">Mohammed Ali</h4>
                      <p className="text-sm text-gray-600">Medical Coding Student</p>
                    </div>
                  </div>
                  <div className="flex">
                    {[...Array(5)].map((_, i) => (
                      <svg key={i} className="w-4 h-4 text-yellow-400 fill-current" viewBox="0 0 20 20">
                        <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                      </svg>
                    ))}
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-gray-700 italic">
                  "Outstanding training institute! Ravan sir's teaching style is unique and very effective. The mock interviews and resume building sessions were extremely helpful. Got placed in Corro Health with a good salary package. Thank you Smart Minds!"
                </p>
                <p className="text-sm text-gray-500 mt-4">2 weeks ago</p>
              </CardContent>
            </Card>

            {/* Review 6 */}
            <Card className="h-full">
              <CardHeader>
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center">
                    <div className="w-12 h-12 bg-maroon-100 rounded-full flex items-center justify-center mr-4">
                      <span className="text-maroon-600 font-bold text-lg">K</span>
                    </div>
                    <div>
                      <h4 className="font-semibold text-gray-900">Kavitha Nair</h4>
                      <p className="text-sm text-gray-600">Clinical Data Management Student</p>
                    </div>
                  </div>
                  <div className="flex">
                    {[...Array(5)].map((_, i) => (
                      <svg key={i} className="w-4 h-4 text-yellow-400 fill-current" viewBox="0 0 20 20">
                        <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                      </svg>
                    ))}
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-gray-700 italic">
                  "Excellent training and placement support! The Clinical Data Management course was comprehensive and the trainers were very supportive. They helped me build confidence through mock interviews. Now working in a top healthcare company. Highly recommended!"
                </p>
                <p className="text-sm text-gray-500 mt-4">1 month ago</p>
              </CardContent>
            </Card>
          </div>

          {/* Google Reviews Link */}
          <div className="text-center mt-12">
            <Button 
              variant="outline" 
              size="lg"
              className="border-maroon-600 text-maroon-600 hover:bg-maroon-600 hover:text-white"
              onClick={() => window.open('https://share.google/gsalhyMeQtsvVz2kX', '_blank')}
            >
              View All Google Reviews
            </Button>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-maroon-600 text-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl font-bold mb-4">Ready to Transform Your Career?</h2>
          <p className="text-xl mb-8">
            Join thousands of successful professionals who started their journey with Smart Minds Academy
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button 
              size="lg" 
              variant="secondary" 
              className="text-lg px-8 py-4 bg-white text-maroon-600 hover:bg-gray-100"
              onClick={() => window.open('https://wa.me/919030070602', '_blank')}
            >
              Enroll Now
            </Button>
            <Button asChild size="lg" variant="outline" className="text-lg px-8 py-4 border-white text-white hover:bg-white hover:text-maroon-600">
              <Link href="/courses">View All Courses</Link>
            </Button>
          </div>
        </div>
      </section>
    </div>
  )
}