'use client'

import Link from 'next/link'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { 
  TrendingUp, 
  Award, 
  Building, 
  MapPin, 
  Calendar,
  Star,
  Users,
  Briefcase,
  CheckCircle
} from 'lucide-react'

export default function PlacementsPage() {
  const placementStats = [
    {
      icon: Users,
      value: "150+ students placed",
      description: "Successful careers launched"
    },
    {
      icon: Building,
      value: "10+",
      label: "Company Partners",
      description: "Leading healthcare and tech companies"
    },
    {
      icon: TrendingUp,
      value: "96%",
      label: "Placement Rate",
      description: "Industry-leading success rate"
    },
    {
      icon: Award,
      value: "4.8/5",
      label: "Student Satisfaction",
      description: "Exceptional training experience"
    }
  ]

  const successStories = [
    {
      name: "Pooja",
      course: "Medical Coding",
      company: "Corro Health",
      position: "Medical Coder",
      rating: 5,
      location: "Hyderabad",
      image: "https://z-cdn-media.chatglm.cn/files/d9de11fe-142c-4f4a-9182-f9951d5ad2e4_pooja.jpg?auth_key=1790424601-a6cef9828e144c96816227833d74c21b-0-4d92952cf3d05dea540430baa9401f9e",
      story: "Hiiii Myself pooja. Ravan sir explanations made me to understand the concepts soo easy. His examples while teaching was very excellent. Today I got selected in corro health company only because of Ravan sir teaching. Iam soo thank full to you sir.",
      placementDate: "Recent"
    },
    {
      name: "Laxman",
      course: "Medical Coding",
      company: "Corro Health",
      position: "Medical Coder",
      rating: 4.5,
      location: "Hyderabad",
      image: "https://z-cdn-media.chatglm.cn/files/d77e1902-71f0-41dc-adf6-e431aa610c5f_laxman.jpg?auth_key=1790424601-cb445958ee534d2cae6a0e06ef5a1137-0-78257ceae132d18096b46aaab38ac302",
      story: "Hiii my name is Laxman. Ravan explains the concept veeeryyyy easily by taking example from nature and our every day lives and I've cracked my interview at Corro health in my first attempt itself. Thank you so much ravan sir.",
      placementDate: "Recent"
    },
    {
      name: "Tejaswini",
      course: "Medical Coding",
      company: "Phycare",
      position: "Medical Coder",
      rating: 5,
      location: "Hyderabad",
      image: "https://z-cdn-media.chatglm.cn/files/57957613-c1e1-4460-8b2c-9c8306964e9d_tejaswini.jpg?auth_key=1790424601-ada4b03d67fc4cd4b7f6ada18539887d-0-604eeca12f0f46c7fff979bca653edd9",
      story: "hiiii, this is tejaswini. Tqq to the entire team from smart mind for creating such a wonderful platform for the learning of medical coding and the teaching was simply superb and easy manner.",
      placementDate: "Recent"
    },
    {
      name: "Venkatesh",
      course: "Medical Coding",
      company: "Corro Health",
      position: "Medical Coder",
      rating: 4,
      location: "Hyderabad",
      image: "https://z-cdn-media.chatglm.cn/files/1c5d16f2-f2a4-4a2c-9b3b-1bf8a7c5dffa_venkatesh.jpg?auth_key=1790424601-581080d1aaa94a7e9161f92753f70278-0-8e30137d88b17d2e7c7f3c8564e00da9",
      story: "hiii my name is venkatesh. This is one of the best institute for the medical coding to learn and gain knowledge nice faculty, flexibility, timings everything is good. I have went for interview, i have selected in 1st attempt... Thank You So Much Ravan Sir... Your Are Such A Excellent Trainer....",
      placementDate: "Recent"
    },
    {
      name: "Anu",
      course: "Medical Coding",
      company: "Augustus Healthcare",
      position: "Medical Coder",
      rating: 4.5,
      location: "Hyderabad",
      image: "https://z-cdn-media.chatglm.cn/files/c444c95e-9cd1-4ef4-a809-44e00fbfe842_anu.jpg?auth_key=1790424601-b311c51bc61b473f82256dcd813e8ca2-0-24fd5c14a453aa1caae3567c9e8c4398",
      story: "One and only institute which makes your dreams successfull in your life in short time period with minimal amount in medical coding is SMART MINDS INSTITUTE. I will definitely give surety about this institute it will gives u a lot of knowledge other than any medical coding institute. I think in few months it will become top most institute. SMART MINDS INSTITUTE.",
      placementDate: "Recent"
    },
    {
      name: "Gnaneshwari",
      course: "Medical Coding",
      company: "Corro Health",
      position: "Medical Coder",
      rating: 5,
      location: "Hyderabad",
      image: "https://z-cdn-media.chatglm.cn/files/c806c338-0b1a-49b7-88bd-405a11e8722e_gnaeshwari.jpg?auth_key=1790424601-85ef218147e148f4bfc6138bc690a65f-0-b519b5c385f3c6f6ddb154dc2d842c60",
      story: "I Am Very Much Satisfied To Be A Part Of This Medical Coding, Especially With The Way Of Teaching, Individual Attention, Great Curriculum, Time Management Skills, Ability To Understand Our Strength And Good Environment. My Sincere Thanks To Ravan Sir For Your Support & Wonderful Teaching. When I was Completed This Medical Coding Training I Have Secured Best Place In Best Company & I Have Selected In Corro Health For The First Attempt. I Am Truly Greatfull To Ravan Sir For Good Explanation & Clearing My Doubt's.",
      placementDate: "Recent"
    },
    {
      name: "Akhila",
      course: "Medical Coding",
      company: "Corro Health",
      position: "Medical Coder",
      rating: 4.5,
      location: "Hyderabad",
      image: "/api/placeholder/150/150",
      story: "Good afternoon sir myself akhila! Thankyou for your medical coding teaching sir, I am so lucky to found teacher as you because you are an a fantastic teacher you motivate the students and get a good confidence in them, you will explain in the way of shortcuts! It's Very Nice Medical Coding Institute Surely We Will Learn More & More Things Trainer's Are Very Good & Excellent. Coaching Is Awesome. Surely You Will Get The Job After Your Training In This Medical Coding Institute They Will Train You Like That Only, I Have Selected In Corro Health For The 1st Attempt.... Thank You So Much Ravan Sir.",
      placementDate: "Recent"
    },
    {
      name: "Sridhar",
      course: "Medical Coding",
      company: "Spyhealth and Corro Health",
      position: "Medical Coder",
      rating: 5,
      location: "Hyderabad",
      image: "/api/placeholder/150/150",
      story: "I had a great experience learning medical coding under Raavan sir at Smart Minds Academy. The teaching style was exceptional, focusing on clear explanations and practical examples that made complex concepts easy to understand. Raavan Sir was incredibly patient, ensuring every doubt was addressed thoroughly. Thanks to this training, I successfully got placed at Spy health. Highly recommend this academy for aspiring medical coders!",
      placementDate: "Recent"
    },
    {
      name: "Swapna",
      course: "Medical Coding",
      company: "Data Marshall",
      position: "Medical Coder",
      rating: 4,
      location: "Hyderabad",
      image: "/api/placeholder/150/150",
      story: "Myself B.Swapna. I joined Smart Minds Academy to take medical coding training. This training was excellent with Good interaction. Especially with the way of teaching and friendly trainer. Smart Minds Academy is the best option for students who wish to begin medical coding as a career.",
      placementDate: "Recent"
    },
    {
      name: "Ch Pavani",
      course: "Medical Coding",
      company: "Corro Health",
      position: "Medical Coder",
      rating: 5,
      location: "Hyderabad",
      image: "/api/placeholder/150/150",
      story: "Ravan sir the great never and ever iam greatful to you sir what you thoughts me exactly happened and what I had learn from you from the begging is came true for me I will always a Lott thank full you sir today iam here is only because of you, thank you sir for everything. The sentence like teachers like 2nd parent that's you in my life, unbreakable teaching sir thank you thank you thank you so much sir.",
      placementDate: "Recent"
    },
    {
      name: "Prasanna",
      course: "Advanced Medical Coding",
      company: "Fedora",
      position: "Senior Medical Coder",
      rating: 4.5,
      location: "Hyderabad",
      image: "/api/placeholder/150/150",
      story: "Recently, I took up advanced medical coding coaching from this institute. Institute trainers are very friendly. I learnt quality subject from them. When it comes to fees, they charge very less compared to others. They not only teach the subject, they prepare us for the purpose of interview. They clarify our doubts without getting irritated. Still they are sharing opportunities in whatsapp official group. Definitely choose this institute if you are interested in medical coding field.",
      placementDate: "Recent"
    },
    {
      name: "Triveni",
      course: "Medical Coding",
      company: "Medcode",
      position: "Medical Coder",
      rating: 5,
      location: "Hyderabad",
      image: "/api/placeholder/150/150",
      story: "I completed my medical coding course at Smart Minds Academy, and I'm delighted to share my experience. The curriculum was comprehensive, covering all aspects of medical coding, including ICD-10 and CPT. The faculty were knowledgeable and supportive, providing individual attention and guidance whenever needed.",
      placementDate: "Recent"
    },
    {
      name: "Ruhina",
      course: "Medical Coding",
      company: "Claimpact",
      position: "Medical Coder",
      rating: 4.5,
      location: "Hyderabad",
      image: "/api/placeholder/150/150",
      story: "Hello everyone, Here, I am ruhina. Regarding this academy, my opinion is the best medical coding institute in hyderabad and it's verrryyy affordable for all, which is helpful for me to develop my confidence level. If you guys are searching for a medical coding institute with low cost, I suggest you can go ahead for this because the teaching staff are well experienced and they make us to learn with a strong attitude and the staff are very friendly with their students. We always enjoy our classes, so this was my best experience in smart minds academy.",
      placementDate: "Recent"
    },
    {
      name: "Cherry (Chandu)",
      course: "Medical Coding",
      company: "Claimpact",
      position: "Medical Coder",
      rating: 4.9,
      location: "Hyderabad",
      image: "/api/placeholder/150/150",
      story: "Smart minds med coding institute is the best y bcz 1. Well experienced teaching staff 2. Price also very less compare to other online institutes 3. Theare explained both English and telugu this is very helpful for Telugu medium students to better understand understanding 4. Theare explaining each nd every guideline which is imp for coding nd also exam point of view. Im giving 4.9🌠 rating",
      placementDate: "Recent"
    },
    {
      name: "Anitha",
      course: "Medical Coding",
      company: "Spyhealth",
      position: "Medical Coder",
      rating: 4,
      location: "Hyderabad",
      image: "/api/placeholder/150/150",
      story: "Naku telsi edhi oka best institute endhuku ante yekkuva quantity tho thakkuva amount tho excellent teaching echi manchi career ni esthundhi and miku medical coding interest vunte e institute lo kachithamga join avandi bcz I got a job in frst attempt bcz of ravan sir thank you smart minds.",
      placementDate: "Recent"
    },
    {
      name: "G. Nikitha",
      course: "Medical Coding",
      company: "Claimpact",
      position: "Medical Coder",
      rating: 5,
      location: "Hyderabad",
      image: "/api/placeholder/150/150",
      story: "Im G.Nikitha, i had the absolute pleasure of learning medical coding from Ravan sir at smart minds institute and I must say, it was unforgettable experience. The faculty has lot of experience and excellent teaching skills. Ravan sir has a unique ability to break down complex topics into simple making learning enjoyable and accessible.",
      placementDate: "Recent"
    },
    {
      name: "Bhagya",
      course: "Medical Coding",
      company: "Spyhealth",
      position: "Medical Coder",
      rating: 4.5,
      location: "Hyderabad",
      image: "/api/placeholder/150/150",
      story: "The teaching is excellent with lively examples. The faculty is very friendly and supportive. They will make sure that you will get job.",
      placementDate: "Recent"
    },
    {
      name: "Chikitha",
      course: "Medical Coding",
      company: "Secqure One",
      position: "Medical Coder",
      rating: 5,
      location: "Hyderabad",
      image: "/api/placeholder/150/150",
      story: "hiii chikitha here. I appreciate how smart minds created a positive environment where all students feel comfortable Participating. your management skills are impressive and this Institute charges very very very less fee when compared to all most all the Institutes outside and The learning activity you introduced was a great way to engage students. I am very glad to be a student of this Institute.",
      placementDate: "Recent"
    },
    {
      name: "Anunay Sai",
      course: "Medical Coding",
      company: "Corro Health",
      position: "Medical Coder",
      rating: 5,
      location: "Hyderabad",
      image: "/api/placeholder/150/150",
      story: "Hey hello creative curious minds. I'm ANUNAY Sai Raj currently working at corrohealth company (Hyderabad). I have been a student of Ravan sir whose guidence and teaching helped me and many of my friends to get job on our first job interview itself from knowing nothing to making us know and learn each and every bit to get a job was all did by Ravan sir and I can surely say he is no doubt the best teacher for Anatomy and medical coding i could have ever got, thanks sir for your friendly nature with live realistic example based teaching. when fun and learning comes together concepts get more easier thanks alot Ravan sir.",
      placementDate: "Recent"
    },
    {
      name: "Ema Sree",
      course: "Medical Coding",
      company: "Gebbs Healthcare",
      position: "Medical Coder",
      rating: 4,
      location: "Hyderabad",
      image: "/api/placeholder/150/150",
      story: "In my perception it is the best medical coding institute in hyderabad. I know that u guys are searching for the best institute with low cost and best knowledge. so, I recommend this institute is the best to improve your skills on medical coding. excellent teaching and we always enjoy the way they teach and guide us for our future. the staff are very knowledgeable and friendly. they made us learning very easy and convenient. thank youu ✨",
      placementDate: "Recent"
    },
    {
      name: "Jyothi",
      course: "Medical Coding",
      company: "Top Healthcare Company",
      position: "Medical Coder",
      rating: 5,
      location: "Hyderabad",
      image: "/api/placeholder/150/150",
      story: "I had ah great experience. the teaching was excellent 👌 smart minds is the best coaching centre to gain knowledge in medical coding. explanation is very good. Ravan sir thankyou so much for teaching us.",
      placementDate: "Recent"
    },
    {
      name: "Sankeerthana",
      course: "Medical Coding",
      company: "Spy Health Solutions",
      position: "Medical Coder",
      rating: 4.5,
      location: "Hyderabad",
      image: "/api/placeholder/150/150",
      story: "we greatly appreciate your commitment to creating a positive environment to all the students krishna satya maam, im placed at spy health solutions. thank you sooo much.",
      placementDate: "Recent"
    },
    {
      name: "Renuka",
      course: "Medical Coding",
      company: "Global Health Solutions",
      position: "Medical Coder",
      rating: 5,
      location: "Hyderabad",
      image: "/api/placeholder/150/150",
      story: "Hiiii this is Renuka. Smart minds Institute is good knowledge gaining Institute. And it is has very reasonable prices for the training and quality is at most outstanding, i will surely recommend this Institute if u want improve your skills and knowledge about medical coding. and im right now placed at global health solutions sir, Personal attention given helped a lot in understanding all the concepts. Ravan sir is really good and explained us with many examples.",
      placementDate: "Recent"
    },
    {
      name: "Pavani",
      course: "Medical Coding",
      company: "Episource",
      position: "Medical Coder",
      rating: 4,
      location: "Hyderabad",
      image: "/api/placeholder/150/150",
      story: "Name: pavani. Smart minds is a good institution having the best experienced faculty. Thank you for a great course. and i got placement at episource company sir, and u got very good presentation style with lots of opportunities to ask questions and talk about real life examples which all made for a really enjoyable and informative course, Like Medical coding.",
      placementDate: "Recent"
    },
    {
      name: "Thanvi",
      course: "Medical Coding",
      company: "Spy Health",
      position: "Medical Coder",
      rating: 4.5,
      location: "Hyderabad",
      image: "/api/placeholder/150/150",
      story: "I had a good experience. The teaching was very excellent. Smart minds is the good coching center who wants to learn medical coding. Theri explaination for students is very good. Thank you so much Ravan sir for teaching us and i got job in spyhealth.",
      placementDate: "Recent"
    },
    {
      name: "Bhavani",
      course: "Medical Coding",
      company: "Global Healthcare Chennai",
      position: "Medical Coder",
      rating: 5,
      location: "Chennai",
      image: "/api/placeholder/150/150",
      story: "i got placed at global healthcare chennai. I had a great experience. The teaching was good and easy to understand. Tha topics will be explained in suitable language like (english, hindi and telugu). Also they are explaining with so many examples to understand the topic.",
      placementDate: "Recent"
    },
    {
      name: "Srilekha",
      course: "Medical Coding",
      company: "Spy Health Solutions",
      position: "Medical Coder",
      rating: 4,
      location: "Hyderabad",
      image: "/api/placeholder/150/150",
      story: "hiiii sir, i got job at spy health solutions at hyderabad, The teaching is excellent with lively examples. The faculty is very friendly and supportive. The materials provided by the faculties help the students to understand the subject very well. They will make sure that you will get job.",
      placementDate: "Recent"
    },
    {
      name: "Gudivada Lakshmi Priya",
      course: "Medical Coding",
      company: "Omega Healthcare & AGS Healthcare",
      position: "Medical Coder",
      rating: 5,
      location: "Chennai & Tirupathi",
      image: "/api/placeholder/150/150",
      story: "Gudivada Lakshmi priya. Feedback: course of medical coding by Ravan Saddam sir (Smart minds), i got job at 2 companies, one is omega healthcare at chennai and another is ags healthcare at tirupathi, thanks a lot for the teaching and guidance sir. Excellent explanation each and every word and easy to explain the topics and two or more times to explain until we are clarity about the topic. Simple words to be used to explain in easy way. Excellent 👍 Thank you sir again.",
      placementDate: "Recent"
    },
    {
      name: "Himaja",
      course: "Medical Coding",
      company: "AGS Tirupathi",
      position: "Medical Coder",
      rating: 4.5,
      location: "Tirupathi",
      image: "/api/placeholder/150/150",
      story: "I'm Himaja, One of the Students of 'Smart Minds'. Suraj sir is my Tutor, He's a phenomenal tutor who makes every term crystal clear with real-time examples and makes class Enjoyable. He also provides the course at very very affordable price than the Market. Medical coding is no more an Uphill Battle with him, and i got my job at ags tirupathi, thank you so much for being with us sir✨",
      placementDate: "Recent"
    },
    {
      name: "Sameera",
      course: "Medical Coding",
      company: "Top Healthcare Company",
      position: "Medical Coder",
      rating: 4.5,
      location: "Hyderabad",
      image: "/api/placeholder/150/150",
      story: "I am very thankful to Smart Mind Institute and especially to Suraj sir. His way of teaching made medical coding very easy to understand. He explained everything clearly, from charts to how to face interviews, which helped me a lot. Because of his guidance, I was able to clear my interview in the first attempt and get a job. This is the best institute where you can easily get placement with proper guidance, Thank you so much.",
      placementDate: "Recent"
    },
    {
      name: "Shaheena",
      course: "Medical Coding",
      company: "Fedora Company",
      position: "Medical Coder",
      rating: 5,
      location: "Hyderabad",
      image: "/api/placeholder/150/150",
      story: "Good evening sir, My internship at Smart Minds Institute in Medical Coding was a valuable experience where I gained practical knowledge, improved my confidence, and sharpened my analytical skills. I am proud to share that this training helped me get placed in Fedora Company. I sincerely thank my trainer, Suraj Saddam Sir, for his constant support and guidance, which motivated me to give my best.",
      placementDate: "Recent"
    },
    {
      name: "Shankar",
      course: "Medical Coding",
      company: "Spy Healthcare",
      position: "Medical Coder",
      rating: 5,
      location: "Hyderabad",
      image: "/api/placeholder/150/150",
      story: "Your are such a good teacher trainer for us.. you teach me very well suraj sir thank you for the training...It is too usefull for us. I am very happy to share this moment with you sir",
      placementDate: "Recent"
    },
    {
      name: "Sanjana",
      course: "Medical Coding",
      company: "Gebbs Healthcare",
      position: "Medical Coder",
      rating: 5,
      location: "Hyderabad",
      image: "/api/placeholder/150/150",
      story: "Hiiii I'm sanjana. I recently completed the medical coding course and had a fantastic learning experience! The course timing was extremely flexible, allowing me to balance my studies with other commitments. Our instructor was exceptional - friendly, approachable, and always willing to help. The teaching style was engaging, and the course material was well-structured and easy to follow. I gained invaluable knowledge and skills in medical coding, which I'm confident will benefit my future career. I highly recommend this course to anyone interested in medical coding.",
      placementDate: "Recent"
    },
    {
      name: "Vaishnavi",
      course: "Medical Coding",
      company: "Corro Health",
      position: "Medical Coder",
      rating: 5,
      location: "Hyderabad",
      image: "/api/placeholder/150/150",
      story: "Sir I got placed at Corro Health sir, thanks a lottt for guiding me and motivating me and making every topic crystal clear to me and also sir u explained many times, the topic that I dint understood and u had a lot of patience sir, thank you so much again sir!",
      placementDate: "Recent"
    }
  ]

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-gradient-to-r from-maroon-600 to-maroon-800 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <div className="text-center">
            <h1 className="text-4xl font-bold mb-4">Student Placements</h1>
            <p className="text-xl opacity-90 max-w-3xl mx-auto">
              Celebrating the success of our students who have transformed their careers with Smart Minds Academy. 
              Join the thousands of professionals who found their dream jobs through our training programs.
            </p>
          </div>
        </div>
      </div>

      {/* Stats Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {placementStats.map((stat, index) => (
              <Card key={index} className="text-center">
                <CardHeader>
                  <stat.icon className="h-12 w-12 text-maroon-600 mx-auto mb-4" />
                  <CardTitle className="text-3xl font-bold text-gray-900">
                    {stat.value}
                  </CardTitle>
                  <CardDescription className="text-lg">
                    {stat.label}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600">{stat.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Success Stories */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Success Stories</h2>
            <p className="text-lg text-gray-600">
              Real stories from real students who achieved their career goals
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {successStories.map((story, index) => (
              <Card key={index} className="h-full hover:shadow-lg transition-shadow duration-300">
                <CardHeader>
                  <div className="flex items-center space-x-4 mb-4">
                    <Avatar className="h-16 w-16">
                      <AvatarImage src={story.image} alt={story.name} />
                      <AvatarFallback className="text-lg">
                        {story.name.split(' ').map(n => n[0]).join('')}
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex-1">
                      <h3 className="font-semibold text-lg">{story.name}</h3>
                      <p className="text-sm text-gray-600">{story.course}</p>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <Building className="h-4 w-4 text-maroon-600" />
                      <span className="font-medium">{story.company}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Briefcase className="h-4 w-4 text-maroon-600" />
                      <span className="text-sm">{story.position}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <MapPin className="h-4 w-4 text-maroon-600" />
                      <span className="text-sm">{story.location}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="font-semibold text-maroon-600">{story.salary}</span>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <p className="text-gray-700 text-sm leading-relaxed">
                      "{story.story}"
                    </p>
                    <div className="flex items-center justify-between text-xs text-gray-500">
                      <div className="flex items-center gap-1">
                        <Calendar className="h-3 w-3" />
                        Placed: {story.placementDate}
                      </div>
                      <Badge variant="secondary" className="text-xs">
                        Success Story
                      </Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Our Achievements */}
      <section className="py-16 bg-maroon-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Our Achievements</h2>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              In a short time, we have turned dreams into success. More than 96% of our students have landed jobs in top MNCs and BPOs.
            </p>
          </div>

          <div className="bg-white rounded-lg shadow-lg p-8">
            <h3 className="text-2xl font-bold text-gray-900 mb-6 text-center">Our Proud Placements</h3>
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="text-center p-4 bg-gray-50 rounded-lg">
                <h4 className="font-semibold text-maroon-600">Corro Health</h4>
                <p className="text-sm text-gray-600">Hyderabad</p>
              </div>
              <div className="text-center p-4 bg-gray-50 rounded-lg">
                <h4 className="font-semibold text-maroon-600">Episource</h4>
                <p className="text-sm text-gray-600">Vijayawada</p>
              </div>
              <div className="text-center p-4 bg-gray-50 rounded-lg">
                <h4 className="font-semibold text-maroon-600">Phycare</h4>
                <p className="text-sm text-gray-600">Mangalagiri</p>
              </div>
              <div className="text-center p-4 bg-gray-50 rounded-lg">
                <h4 className="font-semibold text-maroon-600">Spyhealth</h4>
                <p className="text-sm text-gray-600">Hyderabad</p>
              </div>
              <div className="text-center p-4 bg-gray-50 rounded-lg">
                <h4 className="font-semibold text-maroon-600">Augustus</h4>
                <p className="text-sm text-gray-600">Hyderabad</p>
              </div>
              <div className="text-center p-4 bg-gray-50 rounded-lg">
                <h4 className="font-semibold text-maroon-600">Omega Healthcare</h4>
                <p className="text-sm text-gray-600">Chennai</p>
              </div>
              <div className="text-center p-4 bg-gray-50 rounded-lg">
                <h4 className="font-semibold text-maroon-600">Medcode</h4>
                <p className="text-sm text-gray-600">Hyderabad</p>
              </div>
              <div className="text-center p-4 bg-gray-50 rounded-lg">
                <h4 className="font-semibold text-maroon-600">Gebbs Healthcare</h4>
                <p className="text-sm text-gray-600">Hyderabad</p>
              </div>
              <div className="text-center p-4 bg-gray-50 rounded-lg">
                <h4 className="font-semibold text-maroon-600">Fedora Healthcare</h4>
                <p className="text-sm text-gray-600">Vizag</p>
              </div>
              <div className="text-center p-4 bg-gray-50 rounded-lg">
                <h4 className="font-semibold text-maroon-600">Global Healthcare</h4>
                <p className="text-sm text-gray-600">Chennai</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Placement Process */}
      <section className="py-16 bg-maroon-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Our Placement Process</h2>
            <p className="text-lg text-gray-600">
              A structured approach to ensure your career success
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <Card className="text-center">
              <CardHeader>
                <div className="w-16 h-16 bg-maroon-600 text-white rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-2xl font-bold">1</span>
                </div>
                <CardTitle>Training & Skill Development</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">
                  Comprehensive training with industry-relevant curriculum and hands-on projects
                </p>
              </CardContent>
            </Card>

            <Card className="text-center">
              <CardHeader>
                <div className="w-16 h-16 bg-maroon-600 text-white rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-2xl font-bold">2</span>
                </div>
                <CardTitle>Interview Preparation</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">
                  Mock interviews, resume building, and soft skills training
                </p>
              </CardContent>
            </Card>

            <Card className="text-center">
              <CardHeader>
                <div className="w-16 h-16 bg-maroon-600 text-white rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-2xl font-bold">3</span>
                </div>
                <CardTitle>Job Placement</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">
                  Direct placement drives and campus recruitment with top companies
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-maroon-600 text-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold mb-4">Ready to Be Our Next Success Story?</h2>
          <p className="text-xl mb-8">
            Join thousands of successful professionals who started their journey with Smart Minds Academy
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button 
              size="lg" 
              variant="secondary" 
              className="text-lg px-8 py-4 bg-white text-maroon-600 hover:bg-gray-100"
              onClick={() => window.open('https://wa.me/919030070602', '_blank')}
            >
              Enroll Now
            </Button>
            <Button asChild size="lg" variant="outline" className="text-lg px-8 py-4 border-white text-white hover:bg-white hover:text-maroon-600">
              <Link href="/courses">View All Courses</Link>
            </Button>
          </div>
        </div>
      </section>
    </div>
  )
}