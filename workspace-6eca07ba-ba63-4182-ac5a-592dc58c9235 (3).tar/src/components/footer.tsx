'use client'

import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Phone, Mail, MapPin, Clock } from 'lucide-react'

export default function Footer() {
  return (
    <footer className="bg-black text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Top Row: Smart Minds and Quick Links side by side */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
          {/* Logo and Description - Smart Minds */}
          <div>
            <div className="flex items-center space-x-3 mb-4">
              <div className="relative w-12 h-12">
                <img
                  src="/smart-minds-logo-transparent.png"
                  alt="Smart Minds Academy"
                  className="w-full h-full object-contain"
                />
              </div>
              <div className="flex flex-col">
                <span className="text-xl font-bold">SMART MINDS</span>
                <span className="text-xs text-gray-300">ACADEMY OF REAL-TIME TRAINING</span>
              </div>
            </div>
            <p className="text-gray-300 mb-4">
              Transform your career with our elite quality training programs. 
              Get your dream career on your first attempt with our comprehensive courses and placement support.
            </p>
            <div className="text-2xl font-bold text-maroon-400 mb-2">
              TRAIN - TRANSFORM - TRIUMPH
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/" className="text-gray-300 hover:text-maroon-400 transition-colors">
                  Home
                </Link>
              </li>
              <li>
                <Link href="/courses" className="text-gray-300 hover:text-maroon-400 transition-colors">
                  Courses
                </Link>
              </li>
              <li>
                <Link href="/placements" className="text-gray-300 hover:text-maroon-400 transition-colors">
                  Placements
                </Link>
              </li>
              <li>
                <Link href="/contact" className="text-gray-300 hover:text-maroon-400 transition-colors">
                  Contact Us
                </Link>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Row: Contact Info */}
        <div className="border-t border-gray-800 pt-8">
          <h3 className="text-lg font-semibold mb-6">Contact Info</h3>
          
          {/* Contact Numbers, Address, and Mail side by side */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
            {/* Contact Numbers */}
            <div className="flex items-start space-x-2">
              <Phone className="h-4 w-4 text-maroon-400 mt-1" />
              <div className="text-gray-300">
                <div className="font-semibold mb-2">Contact Numbers:</div>
                <div>+91 9030070602 - SURAJ SIR</div>
                <div>+91 99297623402 - SATYA MA'AM</div>
                <div>+91 7780508023 - SHABNA MA'AM</div>
                <div>+91 7799447861 - MASTANI MA'AM</div>
              </div>
            </div>

            {/* Address */}
            <div className="flex items-start space-x-2">
              <MapPin className="h-4 w-4 text-maroon-400 mt-1" />
              <div className="text-gray-300">
                <div className="font-semibold mb-2">Address:</div>
                <div className="mb-3">
                  <div className="font-medium">Hyderabad:</div>
                  <div>A.S.Rao Nagar, Kapra, Hyderabad, Telangana - 500062</div>
                </div>
                <div>
                  <div className="font-medium">Andhra Pradesh:</div>
                  <div>Station Thota near Sai Baba Temple Beside Nagendra Swamy Temple, Nuzvid, Andhra Pradesh - 521201</div>
                </div>
              </div>
            </div>

            {/* Mail */}
            <div className="flex items-center space-x-2">
              <Mail className="h-4 w-4 text-maroon-400" />
              <div className="text-gray-300">
                <div className="font-semibold mb-2">Email:</div>
                <div>smartmindsins@gmail.com</div>
              </div>
            </div>
          </div>

          {/* Timings under the mail section */}
          <div className="flex items-center space-x-2">
            <Clock className="h-4 w-4 text-maroon-400" />
            <span className="text-gray-300"><strong>Timings:</strong> Mon-Sat: 9AM-6PM</span>
          </div>
        </div>

        <div className="border-t border-gray-800 mt-8 pt-8 text-center">
          <div className="mb-4">
            <Button 
              size="lg"
              className="bg-maroon-600 hover:bg-maroon-700 text-white"
              onClick={() => window.open('https://wa.me/919030070602', '_blank')}
            >
              Enroll Now
            </Button>
          </div>
          <p className="text-gray-400">
            © 2024 Smart Minds Academy of Real-Time Training. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  )
}